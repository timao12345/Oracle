-- Validar backups RMAN --

col start_time for a30
col end_time for a30
col OUTPUT_BYTES_DISPLAY for a30
col TIME_TAKEN_DISPLAY for a30
set lines 300
set pages 500
select session_key,
       input_type,
       status,
       to_char(start_time,'yyyy-mm-dd hh24:mi') start_time,
       to_char(end_time,'yyyy-mm-dd hh24:mi')   end_time,
       output_bytes_display,
       time_taken_display
from v$rman_backup_job_details
where start_time > SYSDATE -5
order by session_key asc;



-- Versão 8i e 9i
col handle for a30
col media for a30
col comments for a30
select recid, device_type, handle, tag, status, start_time, completion_time, elapsed_seconds from V$BACKUP_PIECE;