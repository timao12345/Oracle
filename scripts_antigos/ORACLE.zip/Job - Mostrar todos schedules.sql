-- Mostra todos agendamentos -- 

col schedule_name for a30
col schedule_type for a20
col start_date for a35
col repeat_interval for a30
select schedule_name, schedule_type, start_date, repeat_interval 
from dba_scheduler_schedules;