SELECT ARCH.THREAD# "Thread", ARCH.SEQUENCE# "Ultima Sequencia Recebida", APPL.SEQUENCE# "Ultima Sequencia Aplicada", (ARCH.SEQUENCE# - APPL.SEQUENCE#) "Diferenca" FROM (SELECT THREAD# ,SEQUENCE# FROM V$ARCHIVED_LOG WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$ARCHIVED_LOG GROUP BY THREAD#)) ARCH, (SELECT THREAD# ,SEQUENCE# FROM V$LOG_HISTORY WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$LOG_HISTORY GROUP BY THREAD#)) APPL WHERE ARCH.THREAD# = APPL.THREAD# ORDER BY 1;



-- stop archive replication
alter database recover managed standby database cancel;

-- start archive replication
alter database recover managed standby database using current logfile disconnect;

