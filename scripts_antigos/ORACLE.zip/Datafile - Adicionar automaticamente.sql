-- Adiciona datafile automaticamente no DG --

alter tablespace USER-TABLESPACE add datafile '+DATAGROUP' size 10G;