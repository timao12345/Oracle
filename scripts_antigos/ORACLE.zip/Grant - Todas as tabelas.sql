select 'grant select on MM_ODS.'||table_name||' to REVENUE_MANAGEMENT;' from dba_tables where owner = 'MM_ODS';



select 'grant select on MM_ODS.'||object_name||' to REVENUE_MANAGEMENT;' from dba_objects where owner = 'MM_ODS' and object_type='VIEW';






