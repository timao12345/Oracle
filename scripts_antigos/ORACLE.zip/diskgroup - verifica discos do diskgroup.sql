col a.group_number for a5
col a.disk_number for a5
col name for a15
col path for a35
col label for a20
col diskgroup for a10
col label for a10
select a.group_number, a.disk_number, a.name, b.name as DISKGROUP, a.path, a.label, a.header_status, a.mount_status, a.mode_status, a.state, a.os_mb, a.total_mb, a.free_mb from v$asm_disk a, v$asm_diskgroup b where a.group_number=b.group_number order by a.group_number, a.disk_number;