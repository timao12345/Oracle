select 
'alter user "'||username||'" identified by values '''||extract(xmltype(dbms_metadata.get_xml('USER',username)),'//USER_T/PASSWORD/text()').getStringVal()||''';'  old_password 
from 
   dba_users
where
username like 'LASA_BA';





select 'alter user '||name||' identified by values '''||password||''';' from user$ where spare4 is null and password is not null and name='LASA_BA'
union
select 'alter user '||name||' identified by values '''||spare4||';'||password||''';' from user$ where spare4 is not null and password is not null and name='LASA_BA';



alter user LASA_BA identified by values 'S:17AC21A2591EE0B7292EA613F4EF6109A57D476F6998F133F3C0965E7276;4814B953BD485288';
