col status for a8
col inst_id for a5 for 999
col sid for a5 for 999999
col serial# for a5 for 999999
col username for a15
col osuser for a15
col machine for a12
col event for a30
col program for a20
col sql_id for a15
col logon_time for a20
select s.STATUS, s.inst_id, s.SID, s.serial#, s.USERNAME, s.osuser, s.MACHINE, s.event, s.sql_id, s.program, (last_call_et / 60) "Minutes since active", to_char(s.logon_time,'DD-MON-YYYY HH24:MI:SS') logon_time
 from gv$process p, gv$session s
  where s.PADDR = p.ADDR and s.type != 'BACKGROUND' and s.status='ACTIVE' order by logon_time;


SELECT 'alter system kill session ' || '''' || s.SID || ',' || s.serial# || ',@' || s.inst_id || '''' || ' immediate;' from gv$process p, gv$session s
  where s.PADDR = p.ADDR and s.type != 'BACKGROUND' and s.status='INACTIVE';



  
col osuser for a10
col machine for a20
col username for a20  
col spid for a10
col program for a25
col logon_time for a30
SELECT s.username,
     s.osuser,
     s.sid,
     s.serial#,
     p.spid,
     s.status,
     s.machine,
     s.program,
     TO_CHAR(s.logon_Time,'DD-MON-YYYY HH24:MI:SS') AS logon_time,
	 (last_call_et / 60) "Minutes since active"
   FROM gv$session s
  inner join gv$process p
     on s.paddr = p.addr
  WHERE s.type <> 'BACKGROUND' and s.sid=730 order by logon_time DESC;

  
  
col osuser for a20
col machine for a20
col username for a20
select s.STATUS,s.inst_id,s.SID, s.serial#, s.USERNAME, s.osuser, s.MACHINE,s.SQL_HASH_VALUE, s.sql_id, p.PID, p.SPID
 from gv$process p, gv$session s
  where s.PADDR = p.ADDR and s.type != 'BACKGROUND' and s.sid=532 order by status;
