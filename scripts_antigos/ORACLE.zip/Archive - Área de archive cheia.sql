-- Procedimento para liberar a área de archive quando estourar o espaço em disco

[IMPORTANTE: CASO NÃO HAJA ESPAÇO PARA MOVIMENTAR OS ARCHIVES PARA OUTRO DISCO, 
DELETAR TODOS OS ARCHIVES EM DISCO E SOLICITAR AO TIME DE BACKUP UM BACKUP FULL]

rman target /
delete archivelog all;

[CASO CONTRÁRIO, EXECUTAR O PROCEDIMENTO ABAIXO]

-- 1º Alterar a área de archives default do banco para outro disco e gerar um novo archive

alter system set log_archive_dest_1='LOCATION=/app/oracle/BIP/archive';
alter system switch logfile; -- Irá gerar um archive das transações que estão armazenadas no redo current, liberando espaço de redo para o banco transacionar e efetuar o backup

-- OU MOVER ALGUNS ARCHIVES PARA OUTRO DISCO

-- 3º Logar no RMAN e catalogar os archives que foram movidos
rman target /
catalog start with '/u01/app/oracle/backup';

-- 4º Checar a informação sobre os archives que estão no controlfile estão no disco
crosscheck archivelog all

set lines 2000
set pages 1000
alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';
-- Verifica os archives que já foram pra fita
SELECT THREAD#, SEQUENCE#, FIRST_TIME, NEXT_TIME, ARCHIVED, DELETED, APPLIED, BACKUP_COUNT FROM GV$ARCHIVED_LOG WHERE first_time > SYSDATE -2 ORDER  BY first_time ASC;

SYS@TRAX_ODS> archive log list
Database log mode              Archive Mode
Automatic archival             Enabled
Archive destination            USE_DB_RECOVERY_FILE_DEST
Oldest online log sequence     120458
Next log sequence to archive   120461
Current log sequence           120461

-- Após liberar espaço na área de archive o banco já irá transacionar normalmente, 
-- portanto devemos solicitar ao time de backup para realizar o backup dos archives.
 
 
-- Após o backup finalizar, validar se os archives realmente foram pra fita 

SELECT THREAD#, SEQUENCE#, ARCHIVED, DELETED, BACKUP_COUNT FROM GV$ARCHIVED_LOG; -- Verifica os archives que já foram pra fita

-- Caso os archives que estão em disco já tenham ido para a fita, executar o comando abaixo para deletar todos archives que já foram pra fita.

delete archivelog all backed up 1 times to device type sbt; -- Deleta os archives que já foram para fita pelo menos uma vez  

[IMPORTANTE: NÃO ESQUECER DE VOLTAR O PARÃMETRO LOG_ARCHIVE_DEST PARA A ÁREA DEFAULT]

alter system set log_archive_dest_1='LOCATION=/app/oracle/BIP/archive';

__________________________________________________________________________________________________________________

-- Caso o banco utilize a recovery area, basta apenas alterar o tamanho do parâmetro desde que haja disco suficiente.

alter system set db_recovery_file_dest_size=300G;

