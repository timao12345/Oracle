-- Verifica status da instância --

set lines 220
set pages 1000
col host_name for a20
select INSTANCE_NUMBER,INSTANCE_NAME,HOST_NAME,TO_CHAR(STARTUP_TIME, 'DD/MM/YYYY HH24:MI:SS') as STARTUP,STATUS,DATABASE_STATUS, ARCHIVER from v$instance;

-- Verifica status da instância do RAC --


set lines 220
set pages 1000
col host_name for a20
select INSTANCE_NUMBER,INSTANCE_NAME,HOST_NAME,TO_CHAR(STARTUP_TIME, 'DD/MM/YYYY HH24:MI:SS') as STARTUP_TIME,STATUS,DATABASE_STATUS, ARCHIVER from gv$instance;


select
'Hostname :' || host_name ||chr(10) ||
'Instance name :' || instance_name ||chr(10)||
'DB Start time :' || to_char(STARTUP_TIME,'yyyy/mon/dd hh24:mi:ss') ||chr(10)||
'Current time :' || to_char(sysdate,'yyyy/mon/dd hh24:mi:ss') "Instance Particulars"
from v$instance;


-- Verifica recursos do banco de dados --

select RESOURCE_NAME,CURRENT_UTILIZATION,MAX_UTILIZATION,INITIAL_ALLOCATION,LIMIT_VALUE from v$resource_limit;

-- Verifica parâmetro de processos -- 

set lines 220
set pages 1000
col RESOURCE_NAME for a25
col INITIAL_ALLOCATION for a30
col LIMIT_VALUE for a25
select RESOURCE_NAME,CURRENT_UTILIZATION,MAX_UTILIZATION,INITIAL_ALLOCATION,LIMIT_VALUE from v$resource_limit where RESOURCE_NAME in ('processes','sessions','transactions');

set lines 220
set pages 1000
col RESOURCE_NAME for a25
col INITIAL_ALLOCATION for a30
col LIMIT_VALUE for a25
select INST_ID,RESOURCE_NAME,CURRENT_UTILIZATION,MAX_UTILIZATION,INITIAL_ALLOCATION,LIMIT_VALUE from gv$resource_limit where RESOURCE_NAME in ('processes','sessions','transactions');

-- Verifica tamanho do banco --

select sum(bytes) / 1024 / 1024 / 1024 tamanho_GB from dba_segments;