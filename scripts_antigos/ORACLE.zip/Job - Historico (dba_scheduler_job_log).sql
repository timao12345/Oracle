-- To show job history --

SELECT to_char(log_date, 'DD-MON-YY HH24:MI:SS') TIMESTAMP, job_name,
  job_class, operation, status FROM DBA_SCHEDULER_JOB_LOG
  WHERE job_name like '%CARREGA_DIM_AREA_GEOGRAFICA%' ORDER BY log_date;
  
 SELECT to_char(log_date, 'DD-MON-YY HH24:MI:SS') TIMESTAMP, job_name, status,
   SUBSTR(additional_info, 1, 40) ADDITIONAL_INFO
   FROM dba_scheduler_job_run_details job_name where job_name like '%CARREGA_DIM_AREA_GEOGRAFICA%' ORDER BY log_date;
   
   SELECT JOB_NAME, STATE FROM DBA_SCHEDULER_JOBS
WHERE JOB_NAME = 'CARREGA_DIM_AREA_GEOGRAFICA';

SELECT log_id, to_char(log_date, 'DD-MON-YY HH24:MM:SS') timestamp,
   window_name, operation FROM DBA_SCHEDULER_WINDOW_LOG;
   
   SELECT JOB_NAME, STATE FROM DBA_SCHEDULER_JOBS WHERE JOB_NAME = 'CARREGA_DIM_AREA_GEOGRAFICA';